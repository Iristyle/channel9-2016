Get Started
- Download latest version from CodePlex
- UnZip the package
- Open it in WebMatrix 
- Run site and it should work :)
- Go to your_domain.com/rcAdmin to access control panel (default user: "admin", pwd: "razorc")

Make sure "upfiles", "rcLayouts" and "App_Data" folders have read/write permissions
Visual Studio users - make sure to set the virtual path for your site to "/"

For more visit:
http://www.razorc.net
or http://razorc.codeplex.com/